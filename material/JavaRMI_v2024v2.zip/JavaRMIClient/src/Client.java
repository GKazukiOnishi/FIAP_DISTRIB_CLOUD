import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class Client
{
	public Client() {}

	public static void main(String[] args)
	{
		try
		{
			// obt�m uma refer�ncia para o RMI Registry
			Registry registry = LocateRegistry.getRegistry(null);

			// procura no RMI Registry pela interface "HelloInterface"
			HelloInterface stub = (HelloInterface) registry.lookup("HelloInterface");

			// invoca��o do m�todo remoto
			stub.printMessage();
		}
		catch(Exception e)
		{
			System.out.println("Client exception: " +  e.getMessage());
			e.printStackTrace();
		}
	}
}
