//
// Windows Service main Application
//

#include <stdio.h>
#include <locale.h>     // necess�rio para setlocale()
#include <windows.h>    // necess�rio para fun��es referentes a servi�os

#define     SERVICE_OK          0
#define     SERVICE_WARNING     1
#define     SERVICE_ERROR       -1

// nome do servi�o
char FIAP_SERVICE_NAME[] = "fiapService";
// descri��o do servi�o
char FIAP_SERVICE_DESC[] = "Exemplo Windows Service (fiapService).";
// PATH de execu��o
char FIAP_PATH_EXE_NAME[] = "C:\\temp\\fiapService.exe";

SERVICE_STATUS          gStatus;
SERVICE_STATUS_HANDLE   gStatusHandle;
HANDLE                  ghStopEvent = NULL;

int main(int, char * []);
void InstallService();
void UninstallService();
void InitService();
void WINAPI CtrlHandler(DWORD);
void fiapSetServiceStatus(DWORD, DWORD, DWORD);
int Run(char *);

//
// tabela de ponteiros para fun��es
//
SERVICE_TABLE_ENTRY DispatchTable[] = {
    { FIAP_SERVICE_NAME, (LPSERVICE_MAIN_FUNCTION) InitService },
    { NULL, NULL }
};

//
// argc  : valor inteiro que indica a quantidade de par�metros passados ao chamar o programa
// argv[]: vetor de char que cont�m os par�metros, um para cada string passada na linha de comando
//
// (argv[0] = nome do programa que foi chamado no prompt
//  assim sendo, no m�nimo, argc = 1 (no m�nimo, existir� um par�metro)
//
int main(int argc, char * argv[]) {

    // altera para a localidade padr�o do sistema operacional
    // (para poder usar acentua��o corretamente)
    setlocale(LC_ALL, "");

    if (argc > 2 || (argc == 2 && ! stricmp(argv[1], "/?"))) {
        printf("uso: fiapService [ install | uninstall ]\n");
        return SERVICE_WARNING;
    }

    if (argc == 2 && ! stricmp(argv[1], "install")) {
        InstallService();
        return SERVICE_OK;
    }

    if (argc == 2 && ! stricmp(argv[1], "uninstall")) {
        UninstallService();
        return SERVICE_OK;
    }

    // inicia a thread principal do processo servi�o fiapService
    //
    // ATEN��O
    //
    // StartServiceCtrlDispatcher() ir� retornar ERROR_FAILED_SERVICE_CONTROLLER_CONNECT
    // porque o progama est� sendo executado como aplica��o de console em vez de servi�o
    //
    // para iniciar o servi�o fiapService: net start fiapService
    // para   parar o servi�o fiapService: net stop  fiapService
    //
    // ATEN��O
    //
    if (! StartServiceCtrlDispatcher(DispatchTable)) {
        printf("N�o foi poss�vel iniciar o servi�o fiapService \
               (StartServiceCtrlDispatcher()= ERRO)\n");
        return SERVICE_ERROR;
    }

    return SERVICE_WARNING;
}

void InstallService() {
    SC_HANDLE hSCMgr;
    SC_HANDLE hService;
    TCHAR ExeAddr[MAX_PATH];
    SERVICE_DESCRIPTION sd;
    LPTSTR Desc = FIAP_SERVICE_DESC;

    // obt�m a path do arquivo execut�vel do processo corrente
    // (hModule = NULL : arquivo execut�vel do processo corrente)
    if (! GetModuleFileName(NULL, ExeAddr, MAX_PATH)) {
        printf("N�o foi poss�vel instalar o servi�o fiapService \
               (GetModuleFileName()= ERRO).\n");
        return;
    }

    // conecta-se ao Service Control Manager (SCM)
    // e abre a base de dados de servi�os ativos
    // (lpMachineName = NULL : computador local)
    // (lpDatabaseName = NULL : SERVICES_ACTIVE_DATABASE)
    hSCMgr = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    if (hSCMgr == NULL) {
        printf("N�o foi poss�vel conectar-se ao SCM (OpenSCManager()= ERRO).\n");
        return;
    }

    // cria o servi�o fiapService e o inclui na base de dados do SCM
    hService = CreateService(hSCMgr, FIAP_SERVICE_NAME, FIAP_SERVICE_NAME, SERVICE_ALL_ACCESS,
                             SERVICE_WIN32_OWN_PROCESS, SERVICE_AUTO_START, SERVICE_ERROR_NORMAL,
                             ExeAddr, NULL, NULL, NULL, NULL, NULL);

    if (hService == NULL) {
        // lpBinaryPathName = ExeAddr
        printf("N�o foi poss�vel criar o servi�o fiapService \
               (CreateService()= ERRO : %s).\n", ExeAddr);
        CloseServiceHandle(hSCMgr);
        return;
    }
    else
        printf("Servi�o fiapService instalado com SUCESSO!\nArquivo Execut�vel: %s\n", ExeAddr);

    // atualiza a descri��o do servi�o fiapService
    // (dwInfoLevel = SERVICE_CONFIG_DESCRIPTION)
    sd.lpDescription = Desc;
    if (! ChangeServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION, &sd))
        printf("N�o foi poss�vel atualizar a descri��o do servi�o fiapService \
               (ChangeServiceConfig2()= ERRO).\n");

    CloseServiceHandle(hService);
    CloseServiceHandle(hSCMgr);
}

void UninstallService() {
    SC_HANDLE hSCMgr;
    SC_HANDLE hService;

    // conecta-se ao Service Control Manager (SCM)
    // e abre a base de dados de servi�os ativos
    // (lpMachineName = NULL : computador local)
    // (lpDatabaseName = NULL : SERVICES_ACTIVE_DATABASE)
    hSCMgr = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    if (hSCMgr == NULL) {
        printf("N�o foi poss�vel conectar-se ao SCM (OpenSCManager()= ERRO).\n");
        return;
    }

    // abre o servi�o fiapService para desinstala��o
    // (dwDesiredAccess = DELETE)
    hService = OpenService(hSCMgr, FIAP_SERVICE_NAME, DELETE);
    if (hService == NULL) {
        printf("N�o foi poss�vel desinstalar o servi�o fiapService (OpenService() = ERRO).\n");
        CloseServiceHandle(hSCMgr);
        return;
    }

    // excluiu o servi�o fiapService da base de dados do SCM
    if (! DeleteService(hService))
        printf("N�o foi poss�vel desinstalar o servi�o fiapService \
               (DeleteService() = ERRO : (%d)).\n", (int)(GetLastError()));
    else
        printf("Servi�o fiapService desinstalado com SUCESSO!\n");

    CloseServiceHandle(hService);
    CloseServiceHandle(hSCMgr);
}

void InitService() {
    //
    // ATEN��O
    //
    // a fun��o printf() n�o ser� efetiva se o comando
    // "iniciar servi�o"  for executado atrav�s do SCM
    //
    // ATEN��O
    //
    DWORD erro;

    // registra a fun��o CtrlHandler() para tratar as requisi��es feitas ao servi�o
    gStatusHandle = RegisterServiceCtrlHandler(FIAP_SERVICE_NAME, CtrlHandler);
    if (! gStatusHandle) {

        erro = GetLastError();
        if (erro == ERROR_INVALID_NAME)
            printf("RegisterServiceCtrlHandler()= ERRO (ERROR_INVALID_NAME)\n");
        else if (erro == ERROR_SERVICE_DOES_NOT_EXIST)
            printf("RegisterServiceCtrlHandler()= ERRO (ERROR_SERVICE_DOES_NOT_EXIST)\n");
        else
            printf("RegisterServiceCtrlHandler()= ERRO(%d)\n", (int)(erro));

        return;
    }

    gStatus.dwServiceType = SERVICE_WIN32;
    gStatus.dwServiceSpecificExitCode = 0;
    fiapSetServiceStatus(SERVICE_START_PENDING, NO_ERROR, 3000);

    //
    // ATEN��O
    //
    // qualquer c�digo necess�rio para a execu��o do servi�o
    // ("pr�-requisitos") deve ser inserido neste ponto
    // caso o servi�o demore para ser iniciado:
    // executar a fun��o fiapSetServiceStatus(), status= SERVICE_START_PENDING
    // caso o servi�o apresente algum erro:
    // executar a fun��o fiapSetServiceStatus(), status= SERVICE_STOPPED
    //
    // ATEN��O
    //

    // executa o servi�o fiapservice
    Run(FIAP_PATH_EXE_NAME);

    fiapSetServiceStatus(SERVICE_RUNNING, NO_ERROR, 0);
    // cria um objeto para manipula��o de eventos
    ghStopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
    if (ghStopEvent == NULL) {
        fiapSetServiceStatus(SERVICE_STOPPED, NO_ERROR, 0);
        printf("N�o foi poss�vel criar um objeto para manipula��o de eventos \
               (CreateEvent()= ERRO).\n");
        return;
    }

    WaitForSingleObject(ghStopEvent, INFINITE);
    fiapSetServiceStatus(SERVICE_STOPPED, NO_ERROR, 0);
}

void WINAPI CtrlHandler(DWORD CtrlCmd) {
    // trata as requisi��es feitas ao servi�o
    switch (CtrlCmd) {
        case SERVICE_CONTROL_STOP:
            fiapSetServiceStatus(SERVICE_STOP_PENDING, NO_ERROR, 0);
            SetEvent(ghStopEvent);
            break;

        case SERVICE_CONTROL_PAUSE:
        case SERVICE_CONTROL_CONTINUE:
        case SERVICE_CONTROL_INTERROGATE:
            break;
    }

    fiapSetServiceStatus(gStatus.dwCurrentState, NO_ERROR, 0);
}

void fiapSetServiceStatus(DWORD State, DWORD ExitCode, DWORD Wait) {
    gStatus.dwCurrentState = State;
    gStatus.dwWin32ExitCode = ExitCode;
    gStatus.dwWaitHint = Wait;

    // atualiza o status do servi�o fiapService
    if (State == SERVICE_START_PENDING)
        gStatus.dwControlsAccepted = 0;
    else
        gStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;

    // atualiza o status do servi�o no SCM
    SetServiceStatus(gStatusHandle, &gStatus);
}

int Run(char * Command) {
    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    // preenche a estrutura STARTUPINFO
    si.cb = sizeof(STARTUPINFO);
    si.lpReserved = NULL;
    si.lpDesktop = NULL;
    si.lpTitle = 0;
    si.dwX = si.dwY = si.dwXSize = si.dwYSize =
    si.dwXCountChars = si.dwYCountChars = si.dwFlags = 0;
    si.wShowWindow = SW_NORMAL;
    si.lpReserved2 = NULL;
    si.cbReserved2 = 0;
    si.hStdInput = si.hStdOutput = si.hStdError = 0;

    return CreateProcess(0, Command, 0, 0, 1, 0, 0, 0, &si, &pi);
}
