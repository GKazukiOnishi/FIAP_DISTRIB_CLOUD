import java.rmi.Remote;
import java.rmi.RemoteException;

// interface remota entre cliente e servidor 
public interface HelloInterface extends Remote
{
	public void printMessage() throws RemoteException;
}
