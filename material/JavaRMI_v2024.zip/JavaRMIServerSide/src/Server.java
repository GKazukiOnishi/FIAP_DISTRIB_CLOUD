import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class Server extends HelloImplementation
{
	public Server() {}

	public static void main(String[] args)
	{
		try
		{
			// cria inst�ncia do objeto remoto
			// para implementa��o da interface
			HelloImplementation obj = new HelloImplementation();

			// exporta o objeto remoto para a porta 1099 (porta padr�o)
			HelloInterface stub = 
					(HelloInterface) UnicastRemoteObject.exportObject(obj, 1099);

			// v�nculo do objeto remoto ao RMI Registry
			Registry registry = LocateRegistry.createRegistry(1099);
			registry.bind("HelloInterface", stub);

			System.out.print("Servidor em execu��o... ");
		}
		catch (Exception e)
		{
			System.out.println("EXCE��O: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
