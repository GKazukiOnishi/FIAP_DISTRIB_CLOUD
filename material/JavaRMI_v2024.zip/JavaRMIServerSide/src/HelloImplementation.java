
// implementa��o da interface remota
public class HelloImplementation implements HelloInterface
{
	// implementa��o dos m�todos da interface
	public void printMessage()
	{
		System.out.println("Exemplo de utiliza��o da solu��o de middleware JavaRMI.");
	}
}
